//
//  quizApp.swift
//  quiz
//
//  Created by Sayaka Alam on 20/11/24.
//

import SwiftUI

@main
struct quizApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
