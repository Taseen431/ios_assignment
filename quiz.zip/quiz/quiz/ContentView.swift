import SwiftUI

struct ContentView: View {
    @State private var score = 0
    @State private var currentQuestionIndex = 0
    @State private var userAnswer = ""
    @State private var questions: [MathQuestion] = []
    @State private var isQuizOver = false
    
    // Structure to hold each question and its correct answer
    struct MathQuestion {
        let question: String
        let answer: Int
    }
    
    var body: some View {
        VStack {
            if isQuizOver {
                // Show the score when the quiz is over
                Text("Quiz Over! Your Score: \(score)/5")
                    .font(.title)
                    .padding()
                Button("Restart Quiz") {
                    restartQuiz()
                }
                .padding()
            } else {
                // Display current question and answer input
                if currentQuestionIndex < questions.count {
                    Text(questions[currentQuestionIndex].question)
                        .font(.title)
                        .padding()
                } else {
                    Text("Error: Invalid question index.")
                        .font(.title)
                        .padding()
                }

                TextField("Enter your answer", text: $userAnswer)
                    .keyboardType(.numberPad)
                    .padding()
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button("Submit Answer") {
                    submitAnswer()
                }
                .padding()
                
                // Display the score so far
                Text("Score: \(score)/5")
                    .font(.headline)
                    .padding()
            }
        }
        .onAppear {
            startQuiz()
        }
    }
    
    // Start the quiz by generating questions
    func startQuiz() {
        score = 0
        currentQuestionIndex = 0
        isQuizOver = false
        generateQuestions()
    }
    
    // Generate 5 random questions
    func generateQuestions() {
        questions = (0..<5).map { _ in
            return generateRandomQuestion()
        }
        print("Generated questions: \(questions.count)")  // Debugging line
    }
    
    // Generate a random math question
    func generateRandomQuestion() -> MathQuestion {
        let num1 = Int.random(in: 1...10)
        let num2 = Int.random(in: 1...10)
        let operation = Int.random(in: 0...3)  // 0: Add, 1: Subtract, 2: Multiply, 3: Divide
        
        var question = ""
        var answer = 0
        
        switch operation {
        case 0:
            question = "\(num1) + \(num2)"
            answer = num1 + num2
        case 1:
            question = "\(num1) - \(num2)"
            answer = num1 - num2
        case 2:
            question = "\(num1) × \(num2)"
            answer = num1 * num2
        case 3:
            question = "\(num1) ÷ \(num2)"
            answer = num1 / num2
        default:
            break
        }
        
        return MathQuestion(question: question, answer: answer)
    }
    
    // Submit the user's answer
    func submitAnswer() {
        if let answer = Int(userAnswer), answer == questions[currentQuestionIndex].answer {
            score += 1
        }
        
        // Move to the next question or end the quiz if it's the last question
        if currentQuestionIndex < questions.count - 1 {
            currentQuestionIndex += 1
            userAnswer = ""
        } else {
            isQuizOver = true
        }
    }
    
    // Restart the quiz
    func restartQuiz() {
        startQuiz()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
